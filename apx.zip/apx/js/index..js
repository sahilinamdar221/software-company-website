let xhr = new XMLHttpRequest(); 
let URL = "welcome.html";
// set properties

xhr.open("GET",URL,true);
xhr.onload=function(){
    let extfile=xhr.responseText;
    let welcome=document.getElementById("welcome");
    welcome.innerHTML=extfile;
}

xhr.send();
