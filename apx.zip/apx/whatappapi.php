
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
<?php
if (isset($_POST["submit"])) {
        
        #WhatsAPI Config
        $WhatsAppUsername="";
        $WhatsAppPassword="";
$to = ""; // Contact Form Submission Recipient ( without 0 or + )
if(empty($WhatsAppUsername) || empty($WhatsAppPassword) || empty($to)){
        $errWhatsAppConfig="Please Configure WhatsAPI Details First";
}
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$subject = 'Message from Contact Demo ';
$body ="From: $name\n E-Mail: $email\n Message:\n $message";
 
// Check if name has been entered
if (!$_POST['name']) {
$errName = 'Please enter your name';
}
// Check if email has been entered and is valid
if (!$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
$errEmail = 'Please enter a valid email address';
}
//Check if message has been entered
if (!$_POST['message']) {
$errMessage = 'Please enter your message';
}
 
// If there are no errors, send the email
if (!$errWhatsAppConfig && !$errName && !$errEmail && !$errMessage) {
 
require_once("src/whatsprot.class.php");
 
$wa = new WhatsProt($WhatsAppUsername, "WhatsApp", false);
try {
$wa->connect();
$wa->loginWithPassword($WhatsAppPassword);
} catch(Exception $e) {
        $result='<div class="alert alert-danger">Sorry there was an error sending Your Message. Please Check your WhatsAPI Config Details.</div>';
goto END; break;
        }
  
try {
$wa->sendMessage($to, $body);
while($wa->pollMessage());
    $result='<div class="alert alert-success">Thank You! I will be in touch</div>';
} catch(Exception $e) {
    $result='<div class="alert alert-danger">Sorry there was an error sending Your Message.</div>';
}
 
            END:
}
 
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>WhatsApp Contact Form - PHPHive</title>
 
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="bootstrap/html5shiv.js"></script>
      <script src="bootstrap/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="bootstrap/js/jquery-1.9.0.min.js"></script>
  </head>
  <body>
      <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#" target="_blank"><span class="glyphicon glyphicon-home"></span> MobTools - PHPHive</a>
        </div>
<div class="collapse navbar-collapse pull-right" id="bs-example-navbar-collapse-1" >
          <ul class="nav navbar-nav">
            <li><a href="http://www.phphive.info/category/php-for-beginners/">PHP for Beginners</a></li>
            <li><a href="http://www.phphive.info/category/snippets/">Snippets</a></li>
            <li><a href="http://www.phphive.info/about/">About</a></li>
            <li><a href="http://www.phphive.info/contact/">Contact Us</a></li>
            <li><a href="http://www.phphive.info/request-tutorial/">Request Tutorial</a></li>
          </ul>
        </div>
      </div>
    </div>
 
    <div class="container mainbody">
 
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title">WhatsApp Contact Form</h3>
    </div>
    <div class="panel-body">
 
      <div class="col-lg-12" >
        <div >
          <span class="pull-left">  
 
   <div class="container">
   <div class="row">
   <div class="col-md-6 col-md-offset-3">
<form class="form-horizontal" role="form" method="post" action="index.php">
     <?php echo "<p class='text-danger'>$errWhatsAppConfig</p>";?>
<div class="form-group">
<label for="name" class="col-sm-2 control-label">Name</label>
<div class="col-sm-10">
<input type="text" class="form-control" id="name" name="name" placeholder="First & Last Name" value="<?php echo htmlspecialchars($_POST['name']); ?>">
<?php echo "<p class='text-danger'>$errName</p>";?>
</div>
</div>
<div class="form-group">
<label for="email" class="col-sm-2 control-label">Email</label>
<div class="col-sm-10">
<input type="email" class="form-control" id="email" name="email" placeholder="example@domain.com" value="<?php echo htmlspecialchars($_POST['email']); ?>">
<?php echo "<p class='text-danger'>$errEmail</p>";?>
</div>
</div>
<div class="form-group">
<label for="message" class="col-sm-2 control-label">Message</label>
<div class="col-sm-10">
<textarea class="form-control" rows="4" name="message"><?php echo htmlspecialchars($_POST['message']);?></textarea>
<?php echo "<p class='text-danger'>$errMessage</p>";?>
</div>
</div>
<div class="form-group">
<div class="col-sm-10 col-sm-offset-2">
<input id="submit" name="submit" type="submit" value="Send" class="btn btn-primary">
</div>
</div>
<div class="form-group">
<div class="col-sm-10 col-sm-offset-2">
<?php echo $result; ?>
</div>
</div>
</form>
</div>
</div>   
  
</div>
      </div>
  <BR><BR><BR><BR><BR>
</body>
</html>